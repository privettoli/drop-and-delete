import java.math.BigInteger;

public class MultiplyDiapazon {
    long from, to;
    BigInteger counter = BigInteger.ONE;
    public MultiplyDiapazon(int from , int to){
        this.from = from;
        this.to = to;
    }

    public void sum(){
        for (long i = from; i < to; i++){
            counter = counter.multiply(BigInteger.valueOf(i));
        }
    }

    public BigInteger res(){
        return counter;
    }
}
