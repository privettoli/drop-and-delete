import java.math.BigInteger;

public class AppSumRun {
    public static void main(String[] args){
        for (int i = 1; i < 16; i++){
            String res = AppSumRun.runManyLong(500000, i*2);
            //System.out.println(res);
        }
    }

    public static String runManyLong(int toNumber, int nCPU){
        BigInteger res = BigInteger.ZERO;

        try {
            long startTime = System.currentTimeMillis();
            MultiplyDiapazon[] sumDiapozons = new MultiplyDiapazon[nCPU];
            Thread[] threads = new Thread[nCPU];
            int step = toNumber / nCPU;
            int start = 1;
            for (int i = 0; i < nCPU; i++){
                sumDiapozons[i] = new MultiplyDiapazon(start, i + 1 == nCPU ? toNumber : start + step);
                start += step;
                final int id = i;
                threads[i] = new Thread(() -> {
                    sumDiapozons[id].sum();
                });
            }
            for (int i = 0; i < nCPU; i++){
                threads[i].start();
            }
            for (int i = 0; i < nCPU; i++){
                threads[i].join();
            }
            for (int i = 0; i < nCPU; i++){
                res = res.add(sumDiapozons[i].res());
            }
            System.out.printf("To Number: %d , CPU: %d, resLen: %d, took :%d \n", toNumber, nCPU
                    , res.toString().length(), (System.currentTimeMillis() - startTime));
        } catch (Exception e){
            e.printStackTrace();
        }
        return res.toString();
    }
}
